// Yuklama sinovi: 40 ta bot, 2 savol. Ishga tushirish: node server.js & node test.js
const U = 'ws://localhost:' + (process.env.PORT || 3000) + '/ws', N = +process.env.N || 40;
const open = () => new Promise(r => { const w = new WebSocket(U); w.onopen = () => r(w); });
const wait = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const h = await open(), H = o => h.send(JSON.stringify(o)); let code, key, hs;
  h.onmessage = e => { const m = JSON.parse(e.data); if (m.t === 'created') { code = m.code; key = m.key; } if (m.t === 'state') hs = m; };
  H({ t: 'create', qs: [{ q: '2+2?', o: ['3', '4', '5', '6'], c: 1, time: 8 }, { q: '3+3?', o: ['6', '7', '8', '9'], c: 0, time: 8 }] });
  await wait(300); H({ t: 'host', code, key });
  const bots = [];
  for (let i = 0; i < N; i++) {
    const w = await open(), b = { w, i, leak: false }; bots.push(b);
    w.onmessage = e => {
      const m = JSON.parse(e.data); if (m.t !== 'state') return; b.s = m;
      if (m.state === 'question' && m.correct !== undefined) b.leak = true; // to'g'ri javob oldindan kelmasligi kerak
      if (m.state === 'question' && m.me.ans === null && !b.sent) { b.sent = m.qi; const c = m.qi === 0 ? 1 : 0;
        setTimeout(() => w.send(JSON.stringify({ t: 'answer', i: i % 4 === 0 ? (c + 1) % 4 : c })), Math.random() * 3000);
        setTimeout(() => w.send(JSON.stringify({ t: 'answer', i: c })), 3500); } // ikkinchi urinish — rad etilishi kerak
    };
    w.send(JSON.stringify({ t: 'join', code, name: 'Bot' + (i % 5) })); // ismlar takrorlanadi
  }
  await wait(1000); console.log('Lobby qatnashchilar:', hs.count);
  H({ t: 'start' }); await wait(5000); console.log('Savol 1 javob berganlar:', hs.answered, '/', hs.count, 'holat:', hs.state);
  await wait(5000); console.log('Holat:', hs.state); H({ t: 'next' }); await wait(5000);
  H({ t: 'reveal' }); await wait(500); H({ t: 'next' }); await wait(800);
  console.log('Oxirgi holat:', hs.state, '| Top3:', hs.top.slice(0, 3).map(x => x.n + ':' + x.s).join(', '));
  const ok = bots.filter(b => b.s.state === 'end').length; console.log('Yakunni olgan botlar:', ok, '/', N, '| sizib chiqqan javob:', bots.some(b => b.leak));
  const mx = Math.max(...bots.map(b => b.s.me.score)); console.log('Eng yuqori ball (<=2000):', mx);
  process.exit(0);
})();
